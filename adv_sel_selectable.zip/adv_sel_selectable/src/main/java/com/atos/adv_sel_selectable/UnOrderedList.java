package com.atos.adv_sel_selectable;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UnOrderedList {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");

		WebDriver driver = null;
		driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/autoComplete.html");
		driver.findElement(By.id("tags")).sendKeys("S");
		Thread.sleep(4000);

		List<WebElement> liItem = driver.findElements(By.xpath("//*[@id='ui-id-1']/li"));

		for (WebElement web : liItem) {
			if (web.getText().equalsIgnoreCase("SOAP")) {
				web.click();
			}

		}
		
		
	}
}