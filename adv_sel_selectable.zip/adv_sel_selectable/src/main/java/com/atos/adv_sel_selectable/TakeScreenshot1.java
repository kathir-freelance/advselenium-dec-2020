package com.atos.adv_sel_selectable;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class TakeScreenshot1 {

	public static void main(String[] args) throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");

		WebDriver driver = null;
		driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/autoComplete.html");
		driver.findElement(By.id("tags")).sendKeys("S");
		Thread.sleep(4000);
		
		
		TakesScreenshot tc=(TakesScreenshot)driver;
		File f=tc.getScreenshotAs(OutputType.FILE);
		File dest=new File("C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\screen1.jpg");
		FileHandler.copy(f,dest);
	}

}
