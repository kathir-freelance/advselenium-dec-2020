package com.atos.adv_sel_selectable;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScreenShotusingRobot {

	public static void main(String[] args) throws InterruptedException, AWTException, IOException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");

		WebDriver driver = null;
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/pages/Alert.html");
		
		WebElement w=driver.findElement(By.xpath("//*[@id='contentblock']/section/div[1]/div/div/button"));
		w.click();
		Thread.sleep(4000);
		
		Robot r=null;
		r=new Robot();
		Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
		Rectangle rect=new Rectangle(d);
		
		BufferedImage src=r.createScreenCapture(rect);
		File f=new File("C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\myimg.jpg");
		ImageIO.write(src, "jpg", f);
	}

}
