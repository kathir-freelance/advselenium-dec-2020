package com.atos.adv_sel_selectable;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//register our application with the driver -browser
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");
    	
    	WebDriver driver=null;
    	driver=new ChromeDriver();
    	driver.get("http://leafground.com/pages/selectable.html");
    	List<WebElement> liItems=driver.findElements(By.xpath("//*[@id='selectable']/li"));
    	System.out.println(liItems.size());
    	Actions act=new Actions(driver);
    	act.keyDown(Keys.CONTROL)
    	.click(liItems.get(0))
    	.click(liItems.get(3))
    	.build().perform();
    	
    	
    }
}
