package com.atos.Sel_tootltip_day4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws InvalidFormatException, IOException
    {
    	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");
	 	//WebDriver d1;
 		//d1=new ChromeDriver();
    	 File f=new File("C:\\Users\\DELL\\Desktop\\React1.xlsx");
    	 FileInputStream fis=new FileInputStream(f);
 		XSSFWorkbook wb=new XSSFWorkbook(fis); 
 		XSSFSheet sheet0=wb.getSheetAt(0);
 		
 		sheet0.getRow(0).createCell(2).setCellValue("written");
 		FileOutputStream foStream=new FileOutputStream(f);
 		wb.write(foStream);
 		
 		
// 		String data=sheet0.getRow(0).getCell(0).getStringCellValue();
// 		System.out.println("---> "+data);
// 		String data1=sheet0.getRow(0).getCell(1).getStringCellValue();
// 		System.out.println("---> "+data1);
// 		
 		
 		
 		
    }
}
