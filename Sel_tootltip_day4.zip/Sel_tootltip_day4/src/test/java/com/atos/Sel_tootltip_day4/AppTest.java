package com.atos.Sel_tootltip_day4;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;


public class AppTest{

	@Test
	public void Testcase1(){
	
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");
	  	  
		WebDriver d1;

		d1=new ChromeDriver();

		d1.get("http://leafground.com/pages/tooltip.html");

       WebElement ele1= d1.findElement(By.id("age"));
        
       String tooltip= ele1.getAttribute("title");

       //System.out.println(tooltip);
       Assert.assertEquals("enter your name", tooltip.toLowerCase());
	}
}